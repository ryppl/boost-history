/*
  Copyright 2008 Intel Corporation
 
  Use, modification and distribution are subject to the Boost Software License,
  Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
  http://www.boost.org/LICENSE_1_0.txt).
*/
#ifndef BOOST_POLYGON_VIEW_AS_HPP
#define GBOOST_POLYGON_VIEW_AS_HPP
#include "isotropy.hpp"
#include "point_traits.hpp"
#include "interval_traits.hpp"
#include "rectangle_traits.hpp"
#include "polygon_traits.hpp"
#include "polygon_90_set_traits.hpp"
#include "polygon_45_set_traits.hpp"
#include "polygon_set_traits.hpp"

namespace boost { namespace polygon {
  template <typename GCT, typename T>
  struct view_of {};

  template <typename T1, typename T2>
  view_of<T1, T2> view_as(const T2& obj) { return view_of<T1, T2>(obj); }  

  template <typename T>
  struct view_of<rectangle_concept, T> {
    typedef typename polygon_traits<T>::coordinate_type coordinate_type;
    typedef interval_data<coordinate_type> interval_type;
    rectangle_data<coordinate_type> rect;
    view_of(const T& obj) : rect() {
      point_data<coordinate_type> pts[2];
      typename polygon_traits<T>::iterator_type itr = 
        begin_points(obj), itre = end_points(obj);
      if(itr == itre) return;
      assign(pts[0], *itr);
      ++itr;
      if(itr == itre) return;
      ++itr;
      if(itr == itre) return;
      assign(pts[1], *itr);
      set_points(rect, pts[0], pts[1]);
    }
    inline interval_type get(orientation_2d orient) const {
      return rect.get(orient); }
  };

  template <typename T>
  struct geometry_concept<view_of<rectangle_concept, T> > {
    typedef rectangle_concept type;
  };

  template <typename T>
  struct view_of<polygon_45_concept, T> {
    const T* t;
    view_of(const T& obj) : t(&obj) {}
    typedef typename polygon_traits<T>::coordinate_type coordinate_type;
    typedef typename polygon_traits<T>::iterator_type iterator_type;
    typedef typename polygon_traits<T>::point_type point_type;

    /// Get the begin iterator
    inline iterator_type begin() const {
      return polygon_traits<T>::begin_points(*t);
    }
  
    /// Get the end iterator
    inline iterator_type end() const {
      return polygon_traits<T>::end_points(*t);
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size() const {
      return polygon_traits<T>::size(*t);
    }
  
    /// Get the winding direction of the polygon
    inline winding_direction winding() const {
      return polygon_traits<T>::winding(*t);
    }
  };

  template <typename T>
  struct geometry_concept<view_of<polygon_45_concept, T> > {
    typedef polygon_45_concept type;
  };
  
  template <typename T>
  struct view_of<polygon_90_concept, T> {
    const T* t;
    view_of(const T& obj) : t(&obj) {}
    typedef typename polygon_traits<T>::coordinate_type coordinate_type;
    typedef typename polygon_traits<T>::iterator_type iterator_type;
    typedef typename polygon_traits<T>::point_type point_type;
    typedef iterator_points_to_compact<iterator_type, point_type> compact_iterator_type;

    /// Get the begin iterator
    inline compact_iterator_type begin_compact() const {
      return compact_iterator_type(polygon_traits<T>::begin_points(*t),
                                   polygon_traits<T>::end_points(*t));
    }
  
    /// Get the end iterator
    inline compact_iterator_type end_compact() const {
      return compact_iterator_type(polygon_traits<T>::end_points(*t),
                                   polygon_traits<T>::end_points(*t));
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size() const {
      return polygon_traits<T>::size(*t);
    }
  
    /// Get the winding direction of the polygon
    inline winding_direction winding() const {
      return polygon_traits<T>::winding(*t);
    }
  };

  template <typename T>
  struct geometry_concept<view_of<polygon_90_concept, T> > {
    typedef polygon_90_concept type;
  };

  template <typename T>
  struct view_of<polygon_45_with_holes_concept, T> {
    const T* t;
    view_of(const T& obj) : t(&obj) {}
    typedef typename polygon_traits<T>::coordinate_type coordinate_type;
    typedef typename polygon_traits<T>::iterator_type iterator_type;
    typedef typename polygon_traits<T>::point_type point_type;
    typedef view_of<polygon_45_concept, typename polygon_with_holes_traits<T>::hole_type> hole_type;
    struct iterator_holes_type {
      typedef std::forward_iterator_tag iterator_category;
      typedef hole_type value_type;
      typedef std::ptrdiff_t difference_type;
      typedef const hole_type* pointer; //immutable
      typedef const hole_type& reference; //immutable
      typedef typename polygon_with_holes_traits<T>::iterator_holes_type iht;
      iht internal_itr;
      iterator_holes_type() : internal_itr() {}
      iterator_holes_type(iht iht_in) : internal_itr(iht_in) {}
      inline iterator_holes_type& operator++() {
        ++internal_itr;
        return *this;
      }
      inline const iterator_holes_type operator++(int) {
        iterator_holes_type tmp(*this);
        ++(*this);
        return tmp;
      }
      inline bool operator==(const iterator_holes_type& that) const {
        return (internal_itr == that.internal_itr);
      }
      inline bool operator!=(const iterator_holes_type& that) const {
        return (internal_itr != that.internal_itr);
      }
      inline value_type operator*() const { 
        return view_as<polygon_45_concept>(*internal_itr);
      }
    };
      
    /// Get the begin iterator
    inline iterator_type begin() const {
      return polygon_traits<T>::begin_points(*t);
    }
  
    /// Get the end iterator
    inline iterator_type end() const {
      return polygon_traits<T>::end_points(*t);
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size() const {
      return polygon_traits<T>::size(*t);
    }
  
    /// Get the winding direction of the polygon
    inline winding_direction winding() const {
      return polygon_traits<T>::winding(*t);
    }

    /// Get the begin iterator
    inline iterator_holes_type begin_holes() const {
      return polygon_with_holes_traits<T>::begin_holes(*t);
    }
  
    /// Get the end iterator
    inline iterator_holes_type end_holes() const {
      return polygon_with_holes_traits<T>::end_holes(*t);
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size_holes() const {
      return polygon_with_holes_traits<T>::size_holes(*t);
    }
  
  };

  template <typename T>
  struct geometry_concept<view_of<polygon_45_with_holes_concept, T> > {
    typedef polygon_45_with_holes_concept type;
  };
  
  template <typename T>
  struct view_of<polygon_90_with_holes_concept, T> {
    const T* t;
    view_of(const T& obj) : t(&obj) {}
    typedef typename polygon_traits<T>::coordinate_type coordinate_type;
    typedef typename polygon_traits<T>::iterator_type iterator_type;
    typedef typename polygon_traits<T>::point_type point_type;
    typedef iterator_points_to_compact<iterator_type, point_type> compact_iterator_type;
    typedef view_of<polygon_90_concept, typename polygon_with_holes_traits<T>::hole_type> hole_type;
    struct iterator_holes_type {
      typedef std::forward_iterator_tag iterator_category;
      typedef hole_type value_type;
      typedef std::ptrdiff_t difference_type;
      typedef const hole_type* pointer; //immutable
      typedef const hole_type& reference; //immutable
      typedef typename polygon_with_holes_traits<T>::iterator_holes_type iht;
      iht internal_itr;
      iterator_holes_type() : internal_itr() {}
      iterator_holes_type(iht iht_in) : internal_itr(iht_in) {}
      inline iterator_holes_type& operator++() {
        ++internal_itr;
        return *this;
      }
      inline const iterator_holes_type operator++(int) {
        iterator_holes_type tmp(*this);
        ++(*this);
        return tmp;
      }
      inline bool operator==(const iterator_holes_type& that) const {
        return (internal_itr == that.internal_itr);
      }
      inline bool operator!=(const iterator_holes_type& that) const {
        return (internal_itr != that.internal_itr);
      }
      inline value_type operator*() const { 
        return view_as<polygon_90_concept>(*internal_itr);
      }
    };
      
    /// Get the begin iterator
    inline compact_iterator_type begin_compact() const {
      return compact_iterator_type(polygon_traits<T>::begin_points(*t),
                                   polygon_traits<T>::end_points(*t));
    }
  
    /// Get the end iterator
    inline compact_iterator_type end_compact() const {
      return compact_iterator_type(polygon_traits<T>::end_points(*t),
                                   polygon_traits<T>::end_points(*t));
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size() const {
      return polygon_traits<T>::size(*t);
    }
  
    /// Get the winding direction of the polygon
    inline winding_direction winding() const {
      return polygon_traits<T>::winding(*t);
    }

    /// Get the begin iterator
    inline iterator_holes_type begin_holes() const {
      return polygon_with_holes_traits<T>::begin_holes(*t);
    }
  
    /// Get the end iterator
    inline iterator_holes_type end_holes() const {
      return polygon_with_holes_traits<T>::end_holes(*t);
    }
  
    /// Get the number of sides of the polygon
    inline unsigned int size_holes() const {
      return polygon_with_holes_traits<T>::size_holes(*t);
    }
  
  };

  template <typename T>
  struct geometry_concept<view_of<polygon_90_with_holes_concept, T> > {
    typedef polygon_90_with_holes_concept type;
  };

  template <typename T>
  struct view_of<polygon_90_set_concept, T> {
    typedef typename get_coordinate_type<T, typename geometry_concept<T>::type >::type coordinate_type;

    std::vector<polygon_90_with_holes_data<coordinate_type> > polys;
    view_of(const T& obj) : polys() {
      std::vector<polygon_with_holes_data<coordinate_type> > gpolys;
      assign(gpolys, obj);
      for(typename std::vector<polygon_with_holes_data<coordinate_type> >::iterator itr = gpolys.begin();
          itr != gpolys.end(); ++itr) {
        polys.push_back(polygon_90_with_holes_data<coordinate_type>());
        assign(polys.back(), view_as<polygon_90_with_holes_concept>(*itr));
      }
    }

    typedef typename std::vector<polygon_90_with_holes_data<coordinate_type> >::const_iterator iterator_type;
    typedef view_of operator_arg_type;

    inline iterator_type begin() const {
      return polys.begin();
    }

    inline iterator_type end() const {
      return polys.end();
    }

    inline orientation_2d orient() const { return HORIZONTAL; }

    inline bool clean() const { return false; }

    inline bool sorted() const { return false; }

  };

  template <typename T>
  struct polygon_90_set_traits<view_of<polygon_90_set_concept, T> > {
    typedef typename view_of<polygon_90_set_concept, T>::coordinate_type coordinate_type;
    typedef typename view_of<polygon_90_set_concept, T>::iterator_type iterator_type;
    typedef typename view_of<polygon_90_set_concept, T>::operator_arg_type operator_arg_type;

    static inline iterator_type begin(const view_of<polygon_90_set_concept, T>& polygon_set) {
      return polygon_set.begin();
    }

    static inline iterator_type end(const view_of<polygon_90_set_concept, T>& polygon_set) {
      return polygon_set.end();
    }

    static inline orientation_2d orient(const view_of<polygon_90_set_concept, T>& polygon_set) { 
      return polygon_set.orient(); }

    static inline bool clean(const view_of<polygon_90_set_concept, T>& polygon_set) { 
      return polygon_set.clean(); }

    static inline bool sorted(const view_of<polygon_90_set_concept, T>& polygon_set) { 
      return polygon_set.sorted(); }

  };

  template <typename T>
  struct geometry_concept<view_of<polygon_90_set_concept, T> > {
    typedef polygon_90_set_concept type;
  };

  template <typename T>
  struct view_of<polygon_45_set_concept, T> {
    typedef typename get_coordinate_type<T, typename geometry_concept<T>::type >::type coordinate_type;

    std::vector<polygon_45_with_holes_data<coordinate_type> > polys;
    view_of(const T& obj) : polys() {
      std::vector<polygon_with_holes_data<coordinate_type> > gpolys;
      assign(gpolys, obj);
      for(typename std::vector<polygon_with_holes_data<coordinate_type> >::iterator itr = gpolys.begin();
          itr != gpolys.end(); ++itr) {
        polys.push_back(polygon_45_with_holes_data<coordinate_type>());
        assign(polys.back(), view_as<polygon_45_with_holes_concept>(*itr));
      }
    }

    typedef typename std::vector<polygon_45_with_holes_data<coordinate_type> >::const_iterator iterator_type;
    typedef view_of operator_arg_type;

    inline iterator_type begin() const {
      return polys.begin();
    }

    inline iterator_type end() const {
      return polys.end();
    }

    inline orientation_2d orient() const { return HORIZONTAL; }

    inline bool clean() const { return false; }

    inline bool sorted() const { return false; }

  };

  template <typename T>
  struct polygon_45_set_traits<view_of<polygon_45_set_concept, T> > {
    typedef typename view_of<polygon_45_set_concept, T>::coordinate_type coordinate_type;
    typedef typename view_of<polygon_45_set_concept, T>::iterator_type iterator_type;
    typedef typename view_of<polygon_45_set_concept, T>::operator_arg_type operator_arg_type;

    static inline iterator_type begin(const view_of<polygon_45_set_concept, T>& polygon_set) {
      return polygon_set.begin();
    }

    static inline iterator_type end(const view_of<polygon_45_set_concept, T>& polygon_set) {
      return polygon_set.end();
    }

    static inline orientation_2d orient(const view_of<polygon_45_set_concept, T>& polygon_set) { 
      return polygon_set.orient(); }

    static inline bool clean(const view_of<polygon_45_set_concept, T>& polygon_set) { 
      return polygon_set.clean(); }

    static inline bool sorted(const view_of<polygon_45_set_concept, T>& polygon_set) { 
      return polygon_set.sorted(); }

  };

  template <typename T>
  struct geometry_concept<view_of<polygon_45_set_concept, T> > {
    typedef polygon_45_set_concept type;
  };

}}
#endif
